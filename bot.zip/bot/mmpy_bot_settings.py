# -*- coding: utf-8 -*-
SSL_VERIFY = True  # Whether to perform SSL cert verification
BOT_URL = 'https://sms.huihuang100.com/api/v4'  # with 'http://' and with '/api/v4' path. without trailing slash.
BOT_LOGIN = 'bot@admin.com'
BOT_PASSWORD = 'a123456'
BOT_TOKEN = None # or '<bot-personal-access-token>' if you have set bot personal access token.
BOT_TEAM = '乐赢国际'  # possible in lowercase
WEBHOOK_ID = None # otherwise the bot will attempt to create one